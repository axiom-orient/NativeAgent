from __future__ import annotations

import json
import re
import unittest
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONTRACT = json.loads((ROOT / "tests" / "contract.json").read_text(encoding="utf-8"))
SKILL = (ROOT / "SKILL.md").read_text(encoding="utf-8")
README = (ROOT / "README.md").read_text(encoding="utf-8")
AGENT = (ROOT / "agents" / "openai.yaml").read_text(encoding="utf-8")
CASES = json.loads((ROOT / "tests" / "eval_cases.json").read_text(encoding="utf-8"))
GUARDS = (ROOT / "references" / "semantic-guards.md").read_text(encoding="utf-8")
GUIDANCE = (ROOT / "references" / "language-guidance.md").read_text(encoding="utf-8")
SOURCES = (ROOT / "references" / "source-policy.md").read_text(encoding="utf-8")
MODEL_GUIDE = (ROOT / "tests" / "MODEL_EVAL_GUIDE.md").read_text(encoding="utf-8")


class SkillContractTests(unittest.TestCase):
    def test_required_files_exist(self) -> None:
        for rel in CONTRACT["required_files"]:
            self.assertTrue((ROOT / rel).is_file(), rel)

    def test_frontmatter_name_and_description(self) -> None:
        self.assertTrue(SKILL.startswith("---\n"))
        frontmatter = SKILL.split("---", 2)[1]
        self.assertRegex(frontmatter, rf"(?m)^name:\s*{re.escape(CONTRACT['name'])}\s*$")
        self.assertRegex(frontmatter, r"(?m)^description:\s*.+$")

    def test_explicit_invocation_policy(self) -> None:
        self.assertRegex(AGENT, r"(?m)^\s*allow_implicit_invocation:\s*false\s*$")
        self.assertIn(f"${CONTRACT['name']}", AGENT)

    def test_fixed_boundary_responses(self) -> None:
        self.assertIn(CONTRACT["refusal"], SKILL)
        self.assertIn(CONTRACT["missing"], SKILL)
        by_id = {case["id"]: case for case in CASES}
        self.assertEqual(by_id["boundary-missing-input"]["exact_output"], CONTRACT["missing"])
        for case_id in (
            "boundary-wrong-target-language",
            "boundary-translation-request",
            "boundary-summary-request",
            "boundary-tone-conversion",
        ):
            self.assertEqual(by_id[case_id]["exact_output"], CONTRACT["refusal"])

    def test_required_contract_phrases(self) -> None:
        for phrase in CONTRACT["required_skill_phrases"]:
            self.assertIn(phrase, SKILL)

    def test_reference_links_are_explicit(self) -> None:
        for rel in (
            "references/semantic-guards.md",
            "references/language-guidance.md",
            "references/source-policy.md",
        ):
            self.assertIn(rel, SKILL)

    def test_three_modes_are_present(self) -> None:
        for mode in ("`polish`", "`choose`", "`replace`"):
            self.assertIn(mode, SKILL)

    def test_no_fixed_character_threshold(self) -> None:
        self.assertNotIn("5,000", SKILL)
        self.assertNotRegex(SKILL, r"(?<!\d)5000(?!\d)")
        self.assertIn(CONTRACT["semantic_section_phrase"], SKILL)

    def test_no_automatic_duplicate_deletion(self) -> None:
        self.assertIn(CONTRACT["no_auto_dedup_phrase"], SKILL)

    def test_eval_schema_and_count(self) -> None:
        self.assertGreaterEqual(len(CASES), CONTRACT["minimum_eval_cases"])
        ids = [case.get("id") for case in CASES]
        self.assertEqual(len(ids), len(set(ids)))
        for case in CASES:
            for key, expected_type in (
                ("id", str),
                ("category", str),
                ("input", str),
                ("expected_behavior", str),
                ("must_preserve", list),
                ("forbidden_meaning_changes", list),
            ):
                self.assertIsInstance(case.get(key), expected_type, (case.get("id"), key))

    def test_eval_category_coverage(self) -> None:
        categories = Counter(case["category"] for case in CASES)
        required = {
            "input_boundary",
            "style_cleanup",
            "semantic_guard",
            "word_choice",
            "protected_span",
            "locale_register",
            "edit_discipline",
            "output_contract",
        }
        self.assertTrue(required.issubset(categories), categories)
        self.assertGreaterEqual(categories["semantic_guard"], 10)
        self.assertGreaterEqual(categories["word_choice"], 5)
        self.assertGreaterEqual(categories["input_boundary"], 6)

    def test_semantic_guard_table_matches_cases(self) -> None:
        self.assertGreaterEqual(GUARDS.count("| `"), 10)
        joined = json.dumps(CASES, ensure_ascii=False)
        for phrase in CONTRACT["semantic_probe_phrases"]:
            self.assertIn(phrase, GUARDS)
            self.assertIn(phrase, joined)

    def test_word_choice_examples_exist(self) -> None:
        joined = json.dumps(CASES, ensure_ascii=False)
        for phrase in CONTRACT["word_choice_probe_phrases"]:
            self.assertIn(phrase, GUIDANCE)
            self.assertIn(phrase, joined)

    def test_protected_span_coverage(self) -> None:
        joined = json.dumps(CASES, ensure_ascii=False)
        for token in (
            "3.4.2",
            "2026-07-10",
            "https://example.com/spec",
            "`python3 -m unittest -v`",
            "| contract | PASS |",
        ):
            self.assertIn(token, joined)

    def test_source_policy_has_authoritative_references(self) -> None:
        self.assertGreaterEqual(len(re.findall(r"https://", SOURCES)), 8)
        self.assertIn("User-provided glossary", SOURCES)
        self.assertIn("[UNVERIFIED]", SOURCES)

    def test_static_tests_disclaim_model_quality(self) -> None:
        self.assertIn("Static tests do not prove model quality", MODEL_GUIDE)
        self.assertIn("independent native-language reviewer", MODEL_GUIDE)
        self.assertIn("[UNVERIFIED]", MODEL_GUIDE)

    def test_provenance_and_license_are_present(self) -> None:
        for rel in (
            "LICENSE",
            "NOTICE.md",
            "ORIGIN.md",
            "upstream/koreanize/SKILL.md.snapshot",
            "upstream/koreanize/LICENSE",
            "upstream/koreanize/NOTICE.md",
        ):
            self.assertTrue((ROOT / rel).is_file(), rel)

    def test_upstream_snapshot_is_not_discoverable_as_active_skill(self) -> None:
        upstream = ROOT / "upstream" / "koreanize"
        self.assertTrue((upstream / "SKILL.md.snapshot").is_file())
        self.assertFalse((upstream / "SKILL.md").exists())

    def test_no_todo_or_fake_success(self) -> None:
        joined = "\n".join((SKILL, README, GUIDANCE, MODEL_GUIDE))
        self.assertNotRegex(joined, r"(?i)\bTODO\b")
        self.assertNotIn("fully validated", joined.lower())
        self.assertNotIn("100% accurate", joined.lower())

    def test_readme_invocation_syntax_is_current(self) -> None:
        self.assertNotIn("$" + "$", README)
        self.assertIn("`@`", README)
        self.assertIn("`/skills`", README)
        self.assertIn(f"${CONTRACT['name']}", README)

    def test_agent_prompt_uses_single_dollar(self) -> None:
        self.assertNotIn("$" + "$", AGENT)
        self.assertIn(f"${CONTRACT['name']}", AGENT)

    def test_contract_case_count_is_exact(self) -> None:
        self.assertEqual(len(CASES), CONTRACT["case_count"])

    def test_language_guidance_has_minimum_depth(self) -> None:
        checks = re.findall(r"(?m)^\d+\.\s", GUIDANCE)
        self.assertGreaterEqual(len(checks), 10)
        self.assertGreaterEqual(GUIDANCE.count("|"), 20)


if __name__ == "__main__":
    unittest.main()
