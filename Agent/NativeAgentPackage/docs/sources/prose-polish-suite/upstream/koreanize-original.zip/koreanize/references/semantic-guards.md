# Semantic-preservation guards — 한국어

왼쪽 표현이 어색해 보여도 오른쪽처럼 의미 축을 바꾸지 않습니다. 예문을 고정 출력할 필요는 없지만 구분되는 의미는 반드시 보존합니다.

| Protected expression | Forbidden transformation | Distinction to preserve |
|---|---|---|
| `한 마리는 냉동할 수 있다` | `한 마리는 냉동한다` | 가능성과 실제 행동 |
| `짐작할 수 있었다` | `짐작했다` | 추론 가능성과 실제 인식 행위 |
| `조작하지 않도록 했다` | `조작하지 않게 됐다` | 의도적 조치와 결과 상태 |
| `반복되어 온 생활` | `반복된 생활` | 과거부터 이어진 지속·반복의 상 |
| `기능이 늘면서` | `기능이 늘수록` | 동시 변화와 비례 관계 |
| `이 숫자` | `이 금액` | 수량과 금액이라는 지시 대상 종류 |
| `같지 않았음을 확인할 수 있었다` | `같지 않았다` | 화자의 확인이라는 인식 행위 |
| `구체적인 질문이 필요하다` | `구체적으로 질문해야 한다` | 대상의 필요성과 화자의 의무 |
| `두 번째 버전이 출시됐습니다` | `두 번째 버전은 출시했습니다` | 대상과 행위자의 주술 관계 |
| `이를 통해 원인을 찾았다` | `그 순간 원인을 찾았다` | 인과와 시간 관계 |
| `말할 수는 없다` | `말하기 어렵다` | 불가능·판단 유보와 난이도 |
| `일부 요청에서 실패할 수 있다` | `모든 요청에서 실패한다` | 수량 범위와 가능성 |

## Contrastive check

For every changed sentence, answer all of these for both source and result:

1. Who acts, experiences, knows, infers, or is affected?
2. Is the proposition asserted, negated, conditional, possible, recommended, required, reported, or uncertain?
3. What is the scope of negation, quantifiers, and modifiers?
4. Is the relation causal, conditional, concessive, temporal, contrastive, or additive?
5. Are tense, continuation, repetition, progress, completion, and attempted-versus-achieved status unchanged?
6. Does each demonstrative or pronoun still refer to the same kind of thing: number, price, person, place, version, event, or proposition?
7. Are observation, confirmation, inference, intention, and result state still distinguished?
8. Is locale, address form, and register unchanged?

If any answer differs, roll back the edit even when it sounds more fluent.
