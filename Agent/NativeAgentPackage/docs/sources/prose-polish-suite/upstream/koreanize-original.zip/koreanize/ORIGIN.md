# Origin record

| Field | Value |
|---|---|
| Derived skill | `koreanize` |
| Target language | 한국어 (`ko-KR`) |
| Source archive | `koreanize(10).zip` |
| Source SHA-256 | `f27d5c8788611deaa63dc5b1b029b5892db8feefe7ea7700c3d33b6a530bd0d8` |
| Derivation date | 2026-08-07 |
| Source contract tests | 19/19 passed before derivation |
| Upstream snapshot | `upstream/koreanize/SKILL.md.snapshot` |

The upstream source snapshot and attribution files are stored in `upstream/koreanize/`. The snapshot uses a non-discoverable filename so recursive skill scanners do not treat it as a second active skill. This record is provenance, not a quality certificate.
