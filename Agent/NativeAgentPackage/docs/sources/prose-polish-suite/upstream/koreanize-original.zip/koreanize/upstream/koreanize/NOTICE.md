# Notice

이 스킬은 비교 대상 P1 `koreanize-clean.zip`과 사용자 제공 P2 `koreanize-benchmarked-skill.zip`을 분석해 재구성했습니다.

- P1에서 의미 보호, 입력 경계, 보호 구간, 롤백 규칙, 변경 예산을 trunk로 유지했습니다.
- P2에서 장르 분류, 밀도 기반 탐지, 긴 문서 처리 방식을 선택적으로 가져왔습니다.
- P2의 자동 상태 footer와 과잉 편집을 유발한 규칙은 채택하지 않았습니다.
- P1 패키지의 원래 MIT license 사본은 evidence bundle의 `upstream/p1/LICENSE`에 보존합니다.

P2의 별도 라이선스 표기는 원본 패키지에서 확인되지 않았습니다. 이 전달물은 사용자가 제공한 자료를 사용자 요청에 따라 통합한 결과입니다.
