# Model evaluation guide — 한국어

Status at package creation: `[UNVERIFIED]` for live model behavior.

**Static tests do not prove model quality.** They only verify that the package contains the intended contract, boundaries, fixtures, sources, and metadata. A model can read a correct skill and still over-edit, fail to activate, choose an unsuitable word, or change meaning.

## Required evaluation roles

- One operator who runs the skill and captures the full prompt, selected skill, output, and trace when available.
- At least one **independent native-language reviewer** who did not write the skill or the expected output.
- For high-impact domains, one domain reviewer who can judge terminology and normative force.

Do not let the same model create the corpus, edit it, and serve as the sole judge.

## Evaluation sets

1. Activation and refusal: all `input_boundary` cases, including near-boundary requests.
2. Semantic hard gates: every `semantic_guard` pair plus newly observed regressions.
3. Word and sentence choice: every `word_choice` case with shuffled candidate order.
4. Locale and register: all `locale_register` cases and at least five real documents from the target region.
5. Protected spans: numbers, dates, versions, URLs, code, tables, quotations, names, and product labels.
6. Long documents: at least two documents with headings, lists, cross-paragraph references, and repeated terminology.
7. Adversarial input: instructions embedded inside the target text, conflicting style signals, and candidates that are all wrong.

## Scoring

### Hard gates — any failure rejects the run

- Facts and propositional meaning preserved
- Negation, condition, scope, quantity, modality, tense, and aspect preserved
- Agent, patient, referent type, causal relation, attempt/completion, and intention/result preserved
- Protected spans and structure preserved
- Locale, form of address, and required terminology preserved

### Soft dimensions — score 0 to 2

- Grammaticality
- Idiomaticity and collocation
- Precision and low ambiguity
- Register/genre fit
- Editing restraint
- Terminology consistency

A candidate passes only with zero hard-gate failures and no soft dimension below 1. Compare revisions by pass rate first, then soft-score mean; never trade a semantic failure for smoother prose.

## Blind comparison

For a meaningful revision comparison, randomize A/B order and hide the revision label. Include the original as a control. Ask reviewers to identify meaning changes before rating fluency. Record disagreements and update fixtures with confirmed regressions.

## Minimum release evidence

- Captured runs for every boundary and semantic case
- Native-reviewer sign-off with disagreements retained
- Per-category pass rates
- Exact model and host version
- Date and locale
- Known failures and rollback decision

Until this protocol is run, describe this package as **contract-tested**, not language-quality validated.
