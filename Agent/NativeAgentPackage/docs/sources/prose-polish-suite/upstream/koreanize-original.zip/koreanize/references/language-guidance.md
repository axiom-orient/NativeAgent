# 한국어 language guidance

## Variant contract

기본은 대한민국 표준어(ko-KR)입니다. 북한어·지역어·세대어·조직 고유 문체가 명시되거나 원문에서 일관되면 해당 변이를 보존합니다.

A variant is not an error merely because another region uses a different form. Preserve coherent regional grammar, spelling, vocabulary, address forms, punctuation, and interface terminology unless the user explicitly requests conversion.

## Language-specific checks

1. 조사, 주어·서술어 호응, 높임법, 띄어쓰기와 문장 부호를 문맥 단위로 확인합니다.
2. `~에 의해`, 불필요한 대명사 반복, 영어식 긴 수식어를 기계적으로 지우지 말고 행위자와 초점을 보존하며 고칩니다.
3. 이중 피동과 어색한 사동·피동은 강한 교정 신호지만, 법률·기술 문맥의 의도된 피동은 유지합니다.
4. `것`, `의`, `있다`, `할 수 있다`, `~로 보인다`, `-적`, `-성`, `-화`는 빈도만으로 제거하지 않습니다.
5. 명사화·경량동사(`검토를 수행하다`)는 더 직접적인 동사가 같은 의미·격식을 유지할 때만 바꿉니다.
6. 연결어는 인과·조건·시간·첨가 관계를 부호화하므로 관계가 같을 때만 삭제·교체합니다.
7. 주어 생략은 지시 대상이 명확할 때만 허용하고, 여러 행위자가 있는 문맥에서는 명시성을 우선합니다.
8. 전문 용어, 법정 용어, 제품 용어와 사용자 용어집을 일상어보다 우선합니다.
9. 같은 종결 표현의 반복은 장르와 화자의 리듬을 고려해 국소적으로만 조정합니다.
10. ‘AI가 쓴 글’인지 판정하지 않습니다. 관찰 가능한 반복, 공허한 강조, 기계적 결론 라벨만 편집 신호로 취급합니다.
11. 표준국어대사전·국립국어원 규범·공식 말뭉치를 참고하되, 실제 문맥과 사용자 지정 용례를 우선합니다.
12. 같은 뜻의 화려한 동의어로 교체하지 말고 가장 정확하고 익숙하며 문맥에 일관된 표현을 고릅니다.

## Variant and register regressions

| Preserve | Do not normalize to | Reason |
|---|---|---|
| `고객님께서 확인하셨습니다.` | `고객이 확인했다.` | 존대와 격식을 낮추지 않는다. |
| `거시기 좀 가져와 부러.` | `그것을 가져와 주세요.` | 지역어가 의도된 대화라면 표준어로 평탄화하지 않는다. |

## Contextual word-choice examples

These are decision examples, not globally mandatory replacements.

| Context | Candidates | Preferred in this context | Decisive reason |
|---|---|---|---|
| 성능을 실제로 측정한 결과를 설명 | `효율적이다` / `효과적이다` | `효율적이다` | 같은 결과를 더 적은 시간·비용으로 냈다는 문맥이므로 자원 대비 성과를 뜻하는 표현이 맞다. |
| 버그가 다시 생기지 않게 하는 테스트 | `회귀 테스트` / `반복 테스트` | `회귀 테스트` | 기존 동작이 되돌아가는 결함을 막는 소프트웨어 공학 용어다. |
| 사용자가 버튼을 눌러 기능을 시작 | `실행하다` / `시행하다` | `실행하다` | 프로그램·명령을 작동시키는 문맥이다. |
| 결과가 사실인지 근거로 살핌 | `검증하다` / `확인하다` | `검증하다` | 정해진 기준과 증거로 타당성을 판정하는 의미가 필요하다. |
| 법률 문서에서 의무를 표현 | `할 수 있다` / `해야 한다` | `해야 한다` | 권한·가능성이 아니라 의무를 뜻하는 문맥이다. |

## Operational rule

A dictionary entry proves that a form exists; it does not by itself prove that the form is best in this sentence. Check syntax, collocation, referent, domain, region, register, audience, and document consistency together. When reliable sources disagree, preserve the user's documented convention or report the unresolved variation instead of inventing certainty.
