# Notice

This independent `koreanize` skill was derived from the user-supplied `koreanize(10).zip` contract and extended for 한국어 on 2026-08-07.

- Upstream archive SHA-256: `f27d5c8788611deaa63dc5b1b029b5892db8feefe7ea7700c3d33b6a530bd0d8`
- The upstream source snapshot is preserved as `upstream/koreanize/SKILL.md.snapshot`, with its `LICENSE` and `NOTICE.md`.
- Semantic-preservation priorities and regression-pair methodology originate in the upstream Korean skill.
- The fixed 5,000-character branch was removed; long documents are processed by semantic structure.
- Automatic duplicate-paragraph deletion was removed because it changes content and belongs to a separately requested deduplication operation.
- `choose` and `replace` modes, language-specific variant contracts, evidence hierarchy, and model-evaluation protocol are new in this package.

The work is provided under the included Attribution License. No claim is made that static contract tests prove live model quality.
